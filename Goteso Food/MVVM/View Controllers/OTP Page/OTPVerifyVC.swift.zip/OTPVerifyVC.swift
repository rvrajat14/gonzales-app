//
//  OTPVerifyVC.swift
//  TaxiApp
//
//  Created by Apple on 11/10/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import UIKit
import NotificationCenter

class OTPVerifyVC: UIViewController  {
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var otpView: UIView!
    @IBOutlet weak var otpTxtField: UITextField!
    var isForSignUp = false
    var isForForgotPassword = false
    var signUpDataDic = NSDictionary.init()
     var forgotPasswordDataDic = NSDictionary.init()
    var forgotPaswordEmail = ""
    
    
    var timer: Timer?
    var totalTime = 60

    @IBOutlet weak var regenrateTitleLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var regenerateOtpBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.otpView.layer.cornerRadius = 1
        self.otpView.layer.borderWidth = 1
        self.otpView.layer.borderColor = UIColor.lightGray.cgColor
        startOtpTimer()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
      
    }
    @IBOutlet weak var submitOTPButton: UIButton!
    
    @IBAction func submitOTPButton(_ sender: UIButton) {
        if isForSignUp {
            NotificationCenter.default.post(name: NSNotification.Name.init("signUpOTPNotification"), object: nil, userInfo: ["otp":otpTxtField.text!])
        }
        else
        {
            NotificationCenter.default.post(name: NSNotification.Name.init("forgotPasswordOTPNotification"), object: nil, userInfo: ["otp":otpTxtField.text!])
        }
         ModalTransitionMediator.instance.sendPopoverDismissed(modelChanged: true)
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func regenrateOtpBtnTaped(_ sender: Any) {
        regenerateOtpBtn.isHidden = true
        regenrateTitleLbl.textColor = UIColor.lightGray
        timeLbl.textColor = UIColor.lightGray
        startOtpTimer()
        sendOTP()
    }
    
    private func startOtpTimer() {
        self.totalTime = 60
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        print(self.totalTime)
        
        self.timeLbl.text = "(" + self.timeFormatted(self.totalTime) + ")" // will show timer
        if totalTime != 0 {
            totalTime -= 1  // decrease counter timer
        } else {
            if let timer = self.timer {
                self.regenerateOtpBtn.isHidden = false
                timer.invalidate()
                self.timer = nil
            }
          
            regenerateOtpBtn.isHidden = false
        }
    }
    
    func timeFormatted(_ totalSeconds: Int) -> String {
        let seconds: Int = totalSeconds % 60
        let minutes: Int = (totalSeconds / 60) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    //MARK: OTP API FOR SIGNUP
    //MARK: - Call API
    
    func sendOTP()  {
        
        var param = NSDictionary.init()
        var api_name = ""
        
        if isForSignUp {
            param = signUpDataDic
            api_name = APINAME().REGISTER_OTP_API
        }
        else
        {
          api_name = APINAME().USER_API + "/forgot-password-email"
            param = forgotPasswordDataDic
        }
        
        WebService.requestPostUrlWithJSONDictionaryParameters(strURL: api_name , is_loader_required: true, params: param as! [String : Any], success: { (response) in
            print(response)
            if response["status_code"] as! NSNumber == 1
            {
                self.startOtpTimer()
            }
            
            
        }) { (failure) in
            COMMON_FUNCTIONS.showAlert(msg: "Request Time Out !")
        }
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
